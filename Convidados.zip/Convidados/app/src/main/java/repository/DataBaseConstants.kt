package com.example.convidados.constants

class DataBaseConstants private constructor(){

    object GUEST {

        const val TABLE_NAME = "Guest"
    }
}