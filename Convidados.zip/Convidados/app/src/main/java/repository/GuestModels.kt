package repository

data class GuestModels(val id:Int, var name: String, var presence: Boolean)